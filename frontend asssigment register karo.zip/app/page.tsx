import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { Partners } from "@/components/partners"
import { ServicesSection } from "@/components/services-section"
import { AboutSection } from "@/components/about-section"
import { FeaturesSection } from "@/components/features-section"
import { VideoSection } from "@/components/video-section"
import { ClientsSection } from "@/components/clients-section"
import { ProcessSteps } from "@/components/process-steps"
import { BlogSection } from "@/components/blog-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { FAQSection } from "@/components/faq-section"
import { AppDownloadSection } from "@/components/app-download-section"
import { MetricsSection } from "@/components/metrics-section"
import { NewsletterSection } from "@/components/newsletter-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <Partners />
      <ServicesSection />
      <AboutSection />
      <FeaturesSection />
      <VideoSection />
      <ClientsSection />
      <ProcessSteps />
      <BlogSection />
      <TestimonialsSection />
      <FAQSection />
      <AppDownloadSection />
      <MetricsSection />
      <NewsletterSection />
      <Footer />
    </main>
  )
}

