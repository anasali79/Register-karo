import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import type React from "react" // Import React

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "RegisterKaro - Your Trusted Business Compliance Partner",
  description: "RegisterKaro helps entrepreneurs with business registrations, tax filings, and legal matters.",
  viewport: "width=device-width, initial-scale=1",
  themeColor: "#1e3a8a",
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-icon.png",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        {/* Preload critical assets */}
        <link
          rel="preload"
          href="https://www.registerkaro.in/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FLogo.77348f99.png&w=48&q=75"
          as="image"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}

