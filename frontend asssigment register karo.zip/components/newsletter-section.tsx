"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import { Check } from "lucide-react"

const features = ["Instant results", "User-friendly interface", "Personalized customization"]

const brands = [
  { name: "Spotify", logo: "https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_Green.png" },
  {
    name: "Slack",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Slack_Technologies_Logo.svg/2560px-Slack_Technologies_Logo.svg.png",
  },
  {
    name: "Netflix",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/2560px-Netflix_2015_logo.svg.png",
  },
  {
    name: "Uber",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Uber_logo_2018.svg/2560px-Uber_logo_2018.svg.png",
  },
  {
    name: "Twitter",
    logo: "https://about.twitter.com/content/dam/about-twitter/en/brand-toolkit/brand-download-img-1.jpg.twimg.1920.jpg",
  },
  {
    name: "Airbnb",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Airbnb_Logo_B%C3%A9lo.svg/2560px-Airbnb_Logo_B%C3%A9lo.svg.png",
  },
  // Duplicate for seamless loop
  { name: "Spotify-2", logo: "https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_Green.png" },
  {
    name: "Slack-2",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Slack_Technologies_Logo.svg/2560px-Slack_Technologies_Logo.svg.png",
  },
  {
    name: "Netflix-2",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/2560px-Netflix_2015_logo.svg.png",
  },
  {
    name: "Uber-2",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Uber_logo_2018.svg/2560px-Uber_logo_2018.svg.png",
  },
]

export function NewsletterSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="bg-gradient-to-r from-orange-500 to-blue-900 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-white/80 uppercase text-sm font-medium mb-2">LET'S GET IN TOUCH</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-8">
              Welcome to your new digital reality. Now.
            </h2>

            <form className="max-w-md mx-auto mb-8">
              <div className="flex gap-2">
                <Input
                  type="email"
                  name="email"
                  placeholder="Your email here"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  required
                />
                <Button type="submit" className="bg-white text-blue-900 hover:bg-white/90">
                  Submit
                </Button>
              </div>
            </form>

            <div className="flex flex-wrap justify-center gap-6 mb-12">
              {features.map((feature) => (
                <div key={feature} className="flex items-center gap-2 text-white">
                  <Check className="w-5 h-5" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Brands with Marquee */}
      <div className="bg-white py-8 overflow-hidden">
        <div className="relative">
          <div className="flex animate-marquee space-x-12 py-4">
            {brands.map((brand) => (
              <div key={brand.name} className="flex-shrink-0 w-32 h-12 relative transition-transform hover:scale-110">
                <Image
                  src={brand.logo || "/placeholder.svg"}
                  alt={`${brand.name} logo`}
                  fill
                  className="object-contain"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

