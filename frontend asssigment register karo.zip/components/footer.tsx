import Link from "next/link"
import { Facebook, Twitter, Instagram, Github } from "lucide-react"

const footerLinks = {
  "START A BUSINESS": {
    Features: "#",
    Solutions: "#",
    Integrations: "#",
    Enterprise: "#",
    Solutions: "#",
  },
  "GOVERNMENT REGISTRATION": {
    Partners: "#",
    Community: "#",
    Developers: "#",
    App: "#",
    Blog: "#",
  },
  "COMPLIANCE & TAX": {
    Overview: "#",
    Scale: "#",
    "Watch the Demo": "#",
    "Our Competition": "#",
  },
  "R&D & CSR/CO": {
    "About Us": "#",
    News: "#",
    Leadership: "#",
    "Media Kit": "#",
  },
}

const socialLinks = [
  { name: "Facebook", icon: Facebook, href: "#" },
  { name: "Twitter", icon: Twitter, href: "#" },
  { name: "Github", icon: Github, href: "#" },
  { name: "Instagram", icon: Instagram, href: "#" },
]

export function Footer() {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Top section with description and social links */}
          <div className="mb-12">
            <p className="text-white/80 max-w-md mb-4">
              Design outstanding interfaces with advanced visual features to showcase your digital business in a unique
              way.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  className="text-white/60 hover:text-white transition-colors"
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation Links */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            {Object.entries(footerLinks).map(([category, links]) => (
              <div key={category}>
                <h3 className="font-semibold text-white mb-4">{category}</h3>
                <ul className="space-y-2">
                  {Object.entries(links).map(([label, href]) => (
                    <li key={label}>
                      <Link href={href} className="text-white/60 hover:text-white transition-colors text-sm">
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Copyright */}
          <div className="text-center text-white/60 text-sm">© 2024 RegisterKaro. All Rights Reserved.</div>
        </div>
      </div>
    </footer>
  )
}

