import { Shield, Check, SmilePlus, GraduationCap } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Confidential & Safe",
    description: "All your private information is safe with us",
    bgColor: "bg-red-50",
  },
  {
    icon: Check,
    title: "No Hidden Fee",
    description: "Everything is put before you with no hidden charges or conditions",
    bgColor: "bg-green-50",
  },
  {
    icon: SmilePlus,
    title: "Guaranteed Satisfaction",
    description: "We ensure that you stay 100% satisfied with our offered services",
    bgColor: "bg-blue-50",
  },
  {
    icon: GraduationCap,
    title: "Expert CA/CS Assistance",
    description: "Prompt support from our in-house expert professionals",
    bgColor: "bg-pink-50",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-left mb-12">
            <p className="text-orange-500 uppercase text-sm font-medium">WHY REGISTERKARO.IN</p>
            <h2 className="text-3xl font-bold mt-2">Why Choose Register Karo</h2>
            <p className="text-gray-600 mt-2">
              It is with consistent services and results that build trust with the people and that in turn help us to
              serve the business better
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <div
                key={feature.title}
                className={`${feature.bgColor} rounded-lg p-6 transition-transform hover:-translate-y-1`}
              >
                <div className="mb-4">
                  <feature.icon className="w-8 h-8 text-orange-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

