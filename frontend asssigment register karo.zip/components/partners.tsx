import Image from "next/image"

export function Partners() {
  const partners = [
    { name: "Google", logo: "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png" },
    {
      name: "Microsoft",
      logo: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31",
    },
    { name: "Salesforce", logo: "https://www.salesforce.com/content/dam/sfdc-docs/www/logos/logo-salesforce.svg" },
    { name: "Adobe", logo: "https://www.adobe.com/content/dam/cc/icons/Adobe_Corporate_Horizontal_Red_HEX.svg" },
    { name: "Amazon", logo: "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" },
    { name: "Meta", logo: "https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg" },
    {
      name: "IBM",
      logo: "https://www.ibm.com/design/language/dce3f5b8db2c0dc27e9760f7f8b4f95c/core_blue60_on_white.svg",
    },
    { name: "Oracle", logo: "https://www.oracle.com/a/ocom/img/oracle-red.svg" },
    // Duplicate for seamless loop
    { name: "Google-2", logo: "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png" },
    {
      name: "Microsoft-2",
      logo: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31",
    },
    { name: "Salesforce-2", logo: "https://www.salesforce.com/content/dam/sfdc-docs/www/logos/logo-salesforce.svg" },
    { name: "Adobe-2", logo: "https://www.adobe.com/content/dam/cc/icons/Adobe_Corporate_Horizontal_Red_HEX.svg" },
  ]

  return (
    <section className="py-12 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <h2 className="text-center text-xl text-gray-600 mb-8">Trusted By Over 100+ Startups and freelance business</h2>
        <div className="relative">
          <div className="flex animate-marquee space-x-12 py-4">
            {partners.map((partner) => (
              <div key={partner.name} className="flex-shrink-0 w-32 h-16 relative transition-transform hover:scale-110">
                <Image
                  src={partner.logo || "/placeholder.svg"}
                  alt={`${partner.name} logo`}
                  fill
                  className="object-contain"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

