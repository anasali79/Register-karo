import { Button } from "@/components/ui/button"
import { Building2, FileText, Building, CircleDollarSign, ShoppingCart, BookOpen } from "lucide-react"

const services = [
  {
    icon: Building2,
    title: "Company Formation",
    description: "Build web-based solutions that enhance customer experience.",
    link: "/services/company-formation",
  },
  {
    icon: FileText,
    title: "Company Secretarial Services",
    description: "Make data-driven decisions and utilize technology to reach business goals.",
    link: "/services/secretarial-services",
  },
  {
    icon: Building,
    title: "Virtual Office Address",
    description: "Foster customer relationships by effectively serving your market.",
    link: "/services/virtual-office",
  },
  {
    icon: CircleDollarSign,
    title: "Annual Compliance Services",
    description: "Turn your ideas into modern products with our design experts.",
    link: "/services/compliance",
  },
  {
    icon: ShoppingCart,
    title: "Payroll Services",
    description: "Expand your business across the globe with minimal effort.",
    link: "/services/payroll",
  },
  {
    icon: BookOpen,
    title: "Bookkeeping Services",
    description: "Steering user behaviours with creative design, data insights & technology.",
    link: "/services/bookkeeping",
  },
]

export function ServicesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-orange-500 mb-2 uppercase text-sm font-medium">WELCOME TO REGISTERKARO.IN</p>
          <h2 className="text-3xl font-bold text-gray-900">Explore Our Services</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service) => (
            <div
              key={service.title}
              className="group p-6 bg-white rounded-lg border hover:border-orange-500 transition-colors"
            >
              <div className="mb-4">
                <service.icon className="w-12 h-12 text-orange-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">{service.title}</h3>
              <p className="text-gray-600 mb-4 text-sm">{service.description}</p>
              <a
                href={service.link}
                className="inline-flex items-center text-sm font-medium text-orange-500 hover:text-orange-600"
              >
                Learn more
                <svg
                  className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </a>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" className="border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white">
            See All Services
          </Button>
        </div>
      </div>
    </section>
  )
}

