import Image from "next/image"
import { ArrowUpRight } from "lucide-react"

const blogPosts = [
  {
    id: 1,
    title: "Small business & Startup",
    author: "Prabhash Mishra",
    date: "1 Jan 2023",
    description: "Like to know the secrets of transforming a 2-14 team into a 3x Super Bowl winning Dynasty?",
    image:
      "https://images.unsplash.com/photo-1664575602554-2087b04935a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Tax & Audit", "Management"],
    category: "Today",
  },
  {
    id: 2,
    title: "Scale-Up Company Offer",
    author: "Mahesh Kumar",
    date: "1 Jan 2023",
    description: "Mental models are simple expressions of complex processes or relationships.",
    image:
      "https://images.unsplash.com/photo-1664575600397-88e370cb46b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Tax", "Research", "Compliance"],
    category: "",
  },
  {
    id: 3,
    title: "Growing Business Package",
    author: "Rishi Verma",
    date: "1 Jan 2023",
    description: "Introduction to WhiteSmoke and its Principles. Learn from the best in the industry.",
    image:
      "https://images.unsplash.com/photo-1664575600850-e0dbf3eb5c6d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Audit", "Money Back"],
    category: "",
  },
  {
    id: 4,
    title: "Business Development",
    author: "Karen Kumar",
    date: "1 Jan 2023",
    description: "Create an inclusive environment for remote teams to thrive.",
    image:
      "https://images.unsplash.com/photo-1664575601786-b00156752b61?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Development", "Business"],
    category: "",
  },
  {
    id: 5,
    title: "Strategic Planning",
    author: "Rohit Singh",
    date: "1 Jan 2023",
    description: "Learn effective strategic planning methodologies for business growth.",
    image:
      "https://images.unsplash.com/photo-1664575602276-acd073f104c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Strategy", "Planning"],
    category: "",
  },
  {
    id: 6,
    title: "Digital Marketing",
    author: "Mira Noor",
    date: "1 Jan 2023",
    description: "Master the latest digital marketing techniques and strategies.",
    image:
      "https://images.unsplash.com/photo-1664575602554-2087b04935a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80",
    tags: ["Marketing", "Digital"],
    category: "",
  },
]

export function BlogSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <p className="text-orange-500 uppercase text-sm font-medium">EXPLORE OUR BLOGS</p>
            <h2 className="text-3xl font-bold mt-2">Accelerate Digital Transformation</h2>
          </div>

          {/* Blog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                {/* Image */}
                <div className="relative h-48 md:h-56 lg:h-64">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-sm text-gray-600">
                      {post.author} • {post.date}
                    </div>
                    {post.category && <span className="text-sm text-orange-500">{post.category}</span>}
                  </div>

                  <h3 className="text-xl font-semibold mb-2 group">
                    <a href="#" className="flex items-center gap-2 hover:text-orange-500">
                      {post.title}
                      <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </h3>

                  <p className="text-gray-600 text-sm mb-4">{post.description}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {post.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-block px-3 py-1 text-xs font-medium text-gray-600 bg-gray-100 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

