import Image from "next/image"

export function AppDownloadSection() {
  return (
    <section className="bg-blue-900 py-16 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="max-w-xl">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Manage Your Services by your Mobile Phone
              </h2>
              <p className="text-blue-100 mb-8">
                Download our app to manage and track your services. Our app enables you to stay in touch with our
                experts and also you in tracking your progress.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#" className="transition-transform hover:-translate-y-1">
                  <Image
                    src="https://tools.applemediaservices.com/api/badges/download-on-the-app-store/white/en-us"
                    alt="Download on the App Store"
                    width={140}
                    height={42}
                    className="h-[42px] w-auto"
                  />
                </a>
                <a href="#" className="transition-transform hover:-translate-y-1">
                  <Image
                    src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png"
                    alt="Get it on Google Play"
                    width={160}
                    height={62}
                    className="h-[42px] w-auto"
                  />
                </a>
              </div>
            </div>

            {/* Right Content - Phone Mockups */}
            <div className="relative h-[600px]">
              {/* Background Phone */}
              <div className="absolute right-0 top-10 w-[280px] md:w-[320px]">
                <div className="relative">
                  <Image
                    src="https://www.pngmart.com/files/22/iPhone-14-PNG-Transparent.png"
                    alt="iPhone with RegisterKaro App"
                    width={320}
                    height={650}
                    className="w-full h-auto"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src="https://registerkaro.in/images/logo.png"
                      alt="RegisterKaro Logo"
                      width={150}
                      height={50}
                      className="object-contain"
                    />
                  </div>
                </div>
              </div>
              {/* Foreground Phone */}
              <div className="absolute right-[140px] md:right-[160px] top-[50px] w-[280px] md:w-[320px]">
                <div className="relative">
                  <Image
                    src="https://www.pngmart.com/files/22/iPhone-14-PNG-Transparent.png"
                    alt="iPhone with RegisterKaro App"
                    width={320}
                    height={650}
                    className="w-full h-auto"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src="https://registerkaro.in/images/logo.png"
                      alt="RegisterKaro Logo"
                      width={150}
                      height={50}
                      className="object-contain"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

