"use client"

import { useEffect, useRef } from "react"
import { useInView } from "react-intersection-observer"

const metrics = [
  {
    value: "1M+",
    label: "CUSTOMERS",
  },
  {
    value: "12+",
    label: "YEARS OF EXCELLENCE",
  },
  {
    value: "41+",
    label: "R&D ENGINEERS",
  },
  {
    value: "78+",
    label: "COUNTRIES",
  },
  {
    value: "3287+",
    label: "PARTNERS",
  },
  {
    value: "41+",
    label: "AWARDS RECEIVED",
  },
]

export function MetricsSection() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  return (
    <section className="py-16 bg-white border-t border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange-500 uppercase text-sm font-medium">WHY REGISTERKARO.IN</p>
            <h2 className="text-3xl font-bold mt-2">Some Numbers are important</h2>
          </div>

          <div ref={ref} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 text-center">
            {metrics.map((metric, index) => (
              <div
                key={index}
                className={`transform ${
                  inView ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                } transition-all duration-700 delay-${index * 100}`}
              >
                <div className="text-3xl md:text-4xl font-bold text-blue-900 mb-2">{metric.value}</div>
                <div className="text-sm text-gray-600 uppercase tracking-wider">{metric.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

