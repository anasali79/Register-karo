"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

const faqs = [
  {
    question: "Can I recover deleted files from desktop with this software?",
    answer:
      "Yes, our software provides comprehensive file recovery solutions for desktop systems. It can recover various types of files including documents, images, videos, and more from different scenarios of data loss.",
  },
  {
    question: "Can I recover deleted files from desktop with this software?",
    answer:
      "The software supports recovery from multiple storage devices including internal hard drives, SSDs, external hard drives, and USB drives. It works with both Windows and Mac operating systems.",
  },
  {
    question: "Can I recover deleted files from desktop with this software?",
    answer:
      "Our recovery process is designed to be non-destructive and maintains the integrity of your original files. The software creates a read-only connection with your storage device to prevent any potential data overwriting.",
  },
  {
    question: "Can I recover deleted files from desktop with this software?",
    answer:
      "The recovery success rate depends on various factors including how long ago the files were deleted and whether the storage space has been overwritten. We recommend stopping use of the device immediately after data loss to maximize recovery chances.",
  },
  {
    question: "Can I recover deleted files from desktop with this software?",
    answer:
      "We offer 24/7 technical support to assist you with any questions or issues during the recovery process. Our team of experts can guide you through the entire procedure step by step.",
  },
]

export function FAQSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Frequent Ask Questions</h2>

          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-4">
                <AccordionTrigger className="text-left hover:no-underline">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-gray-600">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="text-center mt-8">
            <Button variant="ghost" className="text-blue-900 hover:text-blue-800">
              Show more
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

