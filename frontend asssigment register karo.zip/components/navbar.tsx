"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Menu, ChevronDown } from "lucide-react"

const navItems = [
  { name: "Home", href: "/" },
  {
    name: "Our Services",
    href: "#",
    subItems: [
      { name: "Company Formation", href: "/services/company-formation" },
      { name: "Annual Compliance", href: "/services/annual-compliance" },
      { name: "Payroll Services", href: "/services/payroll" },
    ],
  },
  { name: "Blog", href: "/blog" },
  { name: "Contact Us", href: "/contact" },
  { name: "About Us", href: "/about" },
]

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const NavLink = ({ item, mobile = false }) => {
    if (item.subItems) {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-1 text-gray-700 hover:text-blue-900 transition-colors duration-200">
            {item.name} <ChevronDown size={16} />
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            {item.subItems.map((subItem) => (
              <DropdownMenuItem key={subItem.href}>
                <Link href={subItem.href} className="w-full">
                  {subItem.name}
                </Link>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      )
    }

    return (
      <Link
        href={item.href}
        className={`${
          pathname === item.href ? "text-blue-900 font-semibold" : "text-gray-700"
        } hover:text-blue-900 transition-colors duration-200 ${
          mobile ? "text-lg py-2" : "px-3 py-2 rounded-md hover:bg-gray-100"
        }`}
        onClick={() => mobile && setIsOpen(false)}
      >
        {item.name}
      </Link>
    )
  }

  return (
    <nav className="w-full bg-white border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <Image
              src="https://www.registerkaro.in/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FLogo.77348f99.png&w=48&q=75"
              alt="RegisterKaro Logo"
              width={32}
              height={32}
              className="w-8 h-8"
            />
            <span className="text-2xl font-bold">
              <span className="text-blue-900">Register</span>
              <span className="text-orange-500">Karo</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <NavLink key={item.name} item={item} />
            ))}
          </div>

          {/* CTA Button */}
          <Button className="hidden md:block bg-orange-500 hover:bg-orange-600 transition-colors duration-200">
            Talk to Expert
          </Button>

          {/* Mobile Menu Button */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" className="md:hidden p-2">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] bg-white"> {/* Background white added */}
              <div className="flex items-center gap-2 mb-8">
                <Image
                  src="https://www.registerkaro.in/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FLogo.77348f99.png&w=48&q=75"
                  alt="RegisterKaro Logo"
                  width={32}
                  height={32}
                  className="w-8 h-8"
                />
                <span className="text-2xl font-bold">
                  <span className="text-blue-900">Register</span>
                  <span className="text-orange-500">Karo</span>
                </span>
              </div>
              <nav className="flex flex-col gap-4">
                {navItems.map((item) => (
                  <NavLink key={item.name} item={item} mobile />
                ))}
                <Button className="mt-4 bg-orange-500 hover:bg-orange-600 transition-colors duration-200">
                  Talk to Expert
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}

