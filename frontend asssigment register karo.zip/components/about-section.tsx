import { Button } from "@/components/ui/button"
import Image from "next/image"

export function AboutSection() {
  return (
    <section className="py-16 bg-gray-50 relative overflow-hidden">
      {/* Decorative dots */}
      <div className="absolute right-0 top-0">
        <svg width="200" height="200" viewBox="0 0 200 200" fill="none">
          <circle cx="6" cy="6" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="32" cy="6" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="58" cy="6" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="6" cy="32" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="32" cy="32" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="58" cy="32" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="6" cy="58" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="32" cy="58" r="6" fill="#FDB241" fillOpacity="0.2" />
          <circle cx="58" cy="58" r="6" fill="#FDB241" fillOpacity="0.2" />
        </svg>
      </div>

      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Left content */}
          <div className="space-y-6">
            <p className="text-orange-500 uppercase text-sm font-medium">WELCOME TO REGISTERKARO.IN</p>
            <h2 className="text-3xl font-bold">
              About <span className="text-orange-500">Register Karo</span>
            </h2>
            <div className="space-y-4 text-gray-600">
              <p>
                We have been using Intelegencia as our DevOps vendor for our field service applications over the last
                couple of years and I'm extremely pleased with their performance, ability to execute, and willingness to
                adapt in our ever changing environment. Perry is an outstanding leader who is focused about customer
                satisfaction. He has built a solid team which has consistently delivered on projects thereby exceeding
                everyone's expectations.
              </p>
              <p>
                I would strongly recommend their services to any organization that is looking for solid, reliable, and
                predictable outcomes.
              </p>
            </div>
            <Button variant="default" className="bg-blue-900 hover:bg-blue-800">
              Learn More
              <svg className="w-4 h-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>
          </div>

          {/* Right content - Team Image */}
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
              alt="Register Karo Team"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

