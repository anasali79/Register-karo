import { FileText, CreditCard, UserCog, Mail } from "lucide-react"

const steps = [
  {
    icon: FileText,
    title: "Fill up Application Form",
  },
  {
    icon: CreditCard,
    title: "Make Online Payment",
  },
  {
    icon: UserCog,
    title: "Executive will Process Application",
  },
  {
    icon: Mail,
    title: "Get Confirm Mail",
  },
]

export function ProcessSteps() {
  return (
    <div className="bg-orange-500 py-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <div key={step.title} className="flex items-center gap-4 text-white">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                  <step.icon className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-grow">
                <p className="font-medium">{step.title}</p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute right-0 top-1/2 transform -translate-y-1/2">
                  <svg className="w-6 h-6 text-white/30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

