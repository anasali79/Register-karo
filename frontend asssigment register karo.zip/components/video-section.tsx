import { Play, Lightbulb, LifeBuoy } from "lucide-react"

export function VideoSection() {
  return (
    <section className="bg-blue-900 py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4">Our Video Introductions</h2>
              <p className="text-blue-100">
                Well-paced sequence helps visualize. Mobile apps and facebook improve volutpate pellentesque a diam
                tincidunt quis dui.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-orange-500/10 p-3 rounded-full">
                  <Lightbulb className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Explore ideas together</h3>
                  <p className="text-blue-100 text-sm">
                    Engage audience segments and finally create actionable insights, amplify vertical integration.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-orange-500/10 p-3 rounded-full">
                  <LifeBuoy className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Bring those ideas to life</h3>
                  <p className="text-blue-100 text-sm">
                    Engage audience segments and finally create actionable insights, amplify vertical integration.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content - YouTube Video */}
          <div className="relative">
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/UdG1AA2gWQs?si=tEMGcZAF8XMRZeuU"
                title="YouTube Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full rounded-lg"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

